// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "TypeRDash",
    products: [
        .library(name: "TypeRDashCore", targets: ["TypeRDashCore"])
    ],
    targets: [
        .target(
            name: "TypeRDashCore",
            path: "TypeRDash",
            exclude: [
                "Assets.xcassets",
                "DashboardView.swift",
                "Info.plist",
                "PrivacyInfo.xcprivacy",
                "Sensors.swift",
                "SettingsView.swift",
                "TypeRDashApp.swift"
            ],
            sources: ["DrivingCore.swift", "GPSFilter.swift"]
        ),
        .testTarget(name: "TypeRDashCoreTests", dependencies: ["TypeRDashCore"], path: "CoreTests")
    ]
)
