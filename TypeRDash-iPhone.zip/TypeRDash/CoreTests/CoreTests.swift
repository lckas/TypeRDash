import Foundation
import XCTest

#if SWIFT_PACKAGE
@testable import TypeRDashCore
#else
@testable import TypeRDash
#endif

final class CoreTests: XCTestCase {
    private let epoch = Date(timeIntervalSince1970: 1_700_000_000)

    func testTransmissionUsesTireDiameterAndRatios() throws {
        var profile = TransmissionProfile.referenceUS
        XCTAssertEqual(profile.tireDiameterM, 0.5961, accuracy: 0.0001)
        XCTAssertEqual(profile.coupledRPM(speedKPH: 100, gear: 5), 2_655, accuracy: 2)
        profile.finalDrive = 4.058
        profile.gearRatios[4] = 0.750
        profile.tireWidthMM = 195
        let restored = try JSONDecoder().decode(TransmissionProfile.self, from: JSONEncoder().encode(profile))
        XCTAssertEqual(profile, restored)
        XCTAssertNotEqual(profile.coupledRPM(speedKPH: 100, gear: 5), 2_655, accuracy: 2)
        profile.gearRatios = [0]
        XCTAssertTrue(profile.coupledRPM(speedKPH: 100, gear: 5).isFinite)
    }

    func testPowertrainShiftsUnderLoadAndDownshiftsUnderBraking() {
        var model = PowertrainModel()
        let profile = TransmissionProfile.referenceUS
        XCTAssertNil(model.update(speedKPH: 0, accelerationMPS2: 0, dt: 1, profile: profile).gear)
        XCTAssertEqual(model.rpm, 825)
        var seen: Set<Int> = []
        for speed in stride(from: 4.0, through: 140.0, by: 0.5) {
            let result = model.update(speedKPH: speed, accelerationMPS2: 2, dt: 0.15, profile: profile)
            if let gear = result.gear { seen.insert(gear) }
            XCTAssertLessThanOrEqual(result.rpm, profile.engineLimitRPM)
        }
        XCTAssertTrue([1, 2, 3, 4].allSatisfy(seen.contains))
        let downshift = stride(from: 140.0, through: 5.0, by: -0.5).contains { speed in
            let previousGear = model.gear ?? 1
            let nextGear = model.update(speedKPH: speed, accelerationMPS2: -2, dt: 0.1, profile: profile).gear ?? 1
            return nextGear < previousGear
        }
        XCTAssertTrue(downshift)
        XCTAssertNil(model.update(speedKPH: nil, accelerationMPS2: 0, dt: 1, profile: profile).gear)
    }

    func testPowertrainDoesNotHuntAtShiftBoundary() {
        var model = PowertrainModel()
        let profile = TransmissionProfile.referenceUS
        _ = model.update(speedKPH: 5, accelerationMPS2: 0, dt: 1, profile: profile)
        var changes = 0
        for index in 0..<100 {
            let previousGear = model.gear
            let speed = index % 2 == 0 ? 32.0 : 31.0
            if model.update(speedKPH: speed, accelerationMPS2: 0, dt: 0.3, profile: profile).gear != previousGear {
                changes += 1
            }
        }
        XCTAssertLessThanOrEqual(changes, 1)
    }

    func testThermalSignalsHeatGraduallyAndCoolWithinDisplayLimits() {
        var model = ThermalModel()
        let first = model.update(speedKPH: 95, accelerationMPS2: 3, rpm: 6_500, dt: 1)
        XCTAssertLessThan(first.oil, 89)
        for _ in 0..<240 { _ = model.update(speedKPH: 95, accelerationMPS2: 3, rpm: 6_500, dt: 1) }
        let hot = model.temperatures
        XCTAssertGreaterThan(hot.engine, 90)
        XCTAssertLessThanOrEqual(hot.engine, 96)
        XCTAssertGreaterThan(hot.oil, 95)
        XCTAssertLessThanOrEqual(hot.oil, 108)
        XCTAssertGreaterThan(hot.intake, 35)
        XCTAssertLessThanOrEqual(hot.intake, 50)
        for _ in 0..<360 { _ = model.update(speedKPH: 95, accelerationMPS2: 0, rpm: 1_800, dt: 1) }
        XCTAssertTrue((85...90).contains(model.temperatures.engine))
        XCTAssertTrue((85...95).contains(model.temperatures.oil))
        XCTAssertTrue((30...40).contains(model.temperatures.intake))
    }

    func testTripMeasuresOnlyConnectedIntervalsAndResets() {
        var trip = TripAccumulator()
        trip.update(speedKPH: 36, at: epoch)
        trip.update(speedKPH: 72, at: epoch.addingTimeInterval(2))
        trip.update(speedKPH: nil, at: epoch.addingTimeInterval(3))
        trip.update(speedKPH: 36, at: epoch.addingTimeInterval(4))
        trip.update(speedKPH: 36, at: epoch.addingTimeInterval(6))
        XCTAssertEqual(trip.distanceKM, 0.05, accuracy: 0.0001)
        XCTAssertEqual(trip.drivingTime, 4)
        XCTAssertEqual(trip.maxKPH, 72)
        XCTAssertEqual(trip.averageKPH, 45, accuracy: 0.001)
        trip.reset()
        XCTAssertEqual(trip.maxKPH, 0)
        XCTAssertEqual(trip.distanceKM, 0)
        XCTAssertEqual(trip.drivingTime, 0)
        XCTAssertEqual(trip.averageKPH, 0)
    }

    func testGPSRejectsInvalidSpeedAndClearsStaleFix() {
        var filter = GPSFilter()
        XCTAssertEqual(filter.reading(at: epoch).quality, .waiting)
        let good = updateGPS(&filter, speedMPS: 20, seconds: 0)
        XCTAssertEqual(good.rawSpeedKPH, 72)
        XCTAssertEqual(good.speedKPH, 72)
        XCTAssertEqual(good.quality, .good)
        let bad = updateGPS(&filter, speedMPS: 20, horizontalAccuracyM: 60, seconds: 1)
        XCTAssertEqual(bad.quality, .lowAccuracy)
        XCTAssertNil(bad.speedKPH)
        XCTAssertEqual(bad.horizontalAccuracyM, 60)
        let stale = filter.reading(at: epoch.addingTimeInterval(4))
        XCTAssertEqual(stale.quality, .lost)
        XCTAssertNil(stale.speedKPH)
        XCTAssertNil(stale.rawSpeedKPH)
        let unknown = updateGPS(&filter, speedMPS: -1, seconds: 5)
        XCTAssertEqual(unknown.quality, .lowAccuracy)
        XCTAssertNil(unknown.speedKPH)
        let recovered = updateGPS(&filter, speedMPS: 10, seconds: 6)
        XCTAssertEqual(recovered.speedKPH, 36)
        let expired = filter.reading(at: epoch.addingTimeInterval(8.5))
        XCTAssertEqual(expired.quality, .lost)
        XCTAssertNil(expired.speedKPH)
    }

    func testGPSQuietsStationaryNoiseAndRejectsOutOfOrderSamples() {
        var filter = GPSFilter()
        XCTAssertEqual(updateGPS(&filter, speedMPS: 0.6, seconds: 0).speedKPH, 0)
        XCTAssertGreaterThan(updateGPS(&filter, speedMPS: 0.8, seconds: 1).speedKPH ?? 0, 0)
        XCTAssertGreaterThan(updateGPS(&filter, speedMPS: 0.5, seconds: 2).speedKPH ?? 0, 0)
        XCTAssertEqual(updateGPS(&filter, speedMPS: 0.4, seconds: 3).speedKPH, 0)
        XCTAssertEqual(updateGPS(&filter, speedMPS: 30, seconds: 2).speedKPH, 0)
    }

    func testDemoProducesAccelerationBrakingAndLateralForce() {
        let accelerating = DemoTelemetry.sample(at: 6)
        let braking = DemoTelemetry.sample(at: 37)
        XCTAssertGreaterThan(accelerating.speedKPH, 0)
        XCTAssertGreaterThan(accelerating.longitudinalG, 0)
        XCTAssertNotEqual(accelerating.lateralG, 0)
        XCTAssertLessThan(braking.accelerationMPS2, 0)
        XCTAssertLessThan(braking.longitudinalG, 0)
        XCTAssertEqual(DemoTelemetry.sample(at: 69).speedKPH, 0)

        var model = PowertrainModel()
        var gears: Set<Int> = []
        for time in stride(from: 0.0, through: 69, by: 0.1) {
            let demo = DemoTelemetry.sample(at: time)
            let output = model.update(
                speedKPH: demo.speedKPH,
                accelerationMPS2: demo.accelerationMPS2,
                dt: 0.1,
                profile: .referenceUS
            )
            if let gear = output.gear { gears.insert(gear) }
        }
        XCTAssertEqual(gears, Set(1...5))
        XCTAssertNil(model.gear)
    }

    private func updateGPS(
        _ filter: inout GPSFilter,
        speedMPS: Double,
        horizontalAccuracyM: Double = 5,
        seconds: TimeInterval
    ) -> GPSReading {
        let timestamp = epoch.addingTimeInterval(seconds)
        return filter.ingest(GPSSample(
            speedMPS: speedMPS,
            speedAccuracyMPS: 0.2,
            horizontalAccuracyM: horizontalAccuracyM,
            timestamp: timestamp
        ), at: timestamp)
    }
}
