import Combine
import SwiftUI
import UIKit

@main
@MainActor
struct TypeRDashApp: App {
    var body: some Scene {
        WindowGroup {
            DashboardScreen()
                .preferredColorScheme(.dark)
        }
    }
}

@MainActor
private struct DashboardScreen: View {
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @StateObject private var model = DashboardModel()
    @State private var showingSettings = false

    var body: some View {
        DashboardView(
            readout: model.readout,
            brightness: model.preferences.brightness,
            redIntensity: model.preferences.redIntensity,
            showTemperatures: model.preferences.showTemperatures,
            startupProgress: model.startupProgress,
            onSettings: { showingSettings = true },
            onStopwatch: { model.toggleStopwatch() }
        )
        .sheet(isPresented: $showingSettings) {
            SettingsView(model: model)
        }
        .onChange(of: showingSettings) { _ in
            setScreenAwake()
        }
        .onChange(of: scenePhase) { phase in
            if phase != .active { model.setActive(false) }
            setScreenAwake()
        }
        .onDisappear {
            model.setActive(false)
            UIApplication.shared.isIdleTimerDisabled = false
        }
        .task(id: scenePhase) {
            guard scenePhase == .active else { return }
            model.setActive(true, reduceMotion: reduceMotion)
            setScreenAwake()
            while !Task.isCancelled {
                model.advance()
                let nanoseconds: UInt64 = model.startupProgress < 1 ? 16_666_667 : 100_000_000
                do {
                    try await Task.sleep(nanoseconds: nanoseconds)
                } catch {
                    return
                }
            }
        }
    }

    private func setScreenAwake() {
        UIApplication.shared.isIdleTimerDisabled = scenePhase == .active && !showingSettings
    }
}

struct DashboardPreferences: Codable, Equatable {
    var brightness = 1.0
    var redIntensity = 0.80
    var showTemperatures = true
    var animateStartup = true
    var transmission = TransmissionProfile.referenceUS
}

private struct Stopwatch {
    private var accumulated: TimeInterval = 0
    private(set) var startedAt: TimeInterval?

    func elapsed(at now: TimeInterval) -> TimeInterval {
        accumulated + (startedAt.map { max(0, now - $0) } ?? 0)
    }

    mutating func toggle(at now: TimeInterval) {
        if startedAt == nil {
            startedAt = now
        } else {
            accumulated = elapsed(at: now)
            startedAt = nil
        }
    }

    mutating func reset(at now: TimeInterval) {
        accumulated = 0
        if startedAt != nil { startedAt = now }
    }
}

@MainActor
final class DashboardModel: ObservableObject {
    @Published private(set) var readout = DashboardReadout(
        speedKPH: nil, rpm: nil, gearLabel: nil,
        coolantC: 85, oilC: 85, intakeC: 30,
        longitudinalG: nil, lateralG: nil, peakG: 0,
        gpsStatus: "AGUARDANDO GPS", gpsAccuracyMeters: nil,
        stopwatchSeconds: 0, stopwatchRunning: false, isDemo: false
    )
    @Published private(set) var preferences: DashboardPreferences
    @Published private(set) var startupProgress = 1.0
    @Published private(set) var liveTrip = TripAccumulator()
    @Published private(set) var demoTrip = TripAccumulator()
    var trip: TripAccumulator { readout.isDemo ? demoTrip : liveTrip }
    var isCalibrated: Bool { motion.isCalibrated }

    private let location = LocationSensor()
    private let motion = MotionSensor()
    private var locationEvents: AnyCancellable?
    private let defaults: UserDefaults
    private static let preferencesKey = "TypeRDash.preferences.v1"
    private var livePowertrain = PowertrainModel()
    private var demoPowertrain = PowertrainModel()
    private var liveThermal = ThermalModel()
    private var demoThermal = ThermalModel()
    private var liveStopwatch = Stopwatch()
    private var demoStopwatch = Stopwatch()
    private var demoPeak = 0.0
    private var demoElapsed: TimeInterval = 0
    private var lastLiveFix: Date?
    private var lastTick: TimeInterval?
    private var startedAnimationAt: TimeInterval?
    private var firstActivation = true
    private var active = false

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        if let data = defaults.data(forKey: Self.preferencesKey),
           let saved = try? JSONDecoder().decode(DashboardPreferences.self, from: data) {
            preferences = saved
        } else {
            preferences = DashboardPreferences()
        }
        locationEvents = location.$reading.sink { [weak self] reading in
            self?.recordLocation(reading)
        }
    }

    func setActive(_ newValue: Bool, reduceMotion: Bool = false) {
        guard newValue != active else { return }
        active = newValue
        lastTick = nil
        if active {
            if firstActivation && preferences.animateStartup && !reduceMotion {
                startedAnimationAt = ProcessInfo.processInfo.systemUptime
                startupProgress = 0
            }
            firstActivation = false
            if !readout.isDemo { startSensors() }
        } else {
            if startedAnimationAt != nil { firstActivation = true }
            startedAnimationAt = nil
            startupProgress = 1
            stopSensors()
            if readout.isDemo { demoTrip.update(speedKPH: nil, at: Date()) }
            if !readout.isDemo { clearLiveReadout() }
        }
    }

    func configure(_ update: (inout DashboardPreferences) -> Void) {
        var updated = preferences
        update(&updated)
        guard updated != preferences else { return }
        if updated.transmission != preferences.transmission {
            livePowertrain = PowertrainModel()
            demoPowertrain = PowertrainModel()
        }
        preferences = updated
        if let data = try? JSONEncoder().encode(updated) {
            defaults.set(data, forKey: Self.preferencesKey)
        }
    }

    func setDemo(_ enabled: Bool) {
        guard enabled != readout.isDemo else { return }
        if enabled {
            stopSensors()
            demoElapsed = 0
            demoPeak = 0
            demoPowertrain = PowertrainModel()
            demoThermal = ThermalModel()
            demoTrip.reset()
            demoStopwatch = Stopwatch()
            clearLiveReadout()
            readout.isDemo = true
        } else {
            readout.isDemo = false
            clearLiveReadout()
            if active { startSensors() }
        }
        lastTick = nil
        advance()
    }

    func toggleStopwatch() {
        let now = ProcessInfo.processInfo.systemUptime
        if readout.isDemo {
            demoStopwatch.toggle(at: now)
        } else {
            liveStopwatch.toggle(at: now)
        }
        updateStopwatch(at: now)
    }

    func resetStopwatch() {
        let now = ProcessInfo.processInfo.systemUptime
        if readout.isDemo {
            demoStopwatch.reset(at: now)
        } else {
            liveStopwatch.reset(at: now)
        }
        updateStopwatch(at: now)
    }

    func resetStats() {
        if readout.isDemo {
            demoTrip.reset()
            demoPeak = 0
        } else {
            liveTrip.reset()
            lastLiveFix = location.reading.timestamp
            motion.resetPeak()
        }
        readout.peakG = 0
    }

    func calibrateMotion() -> Bool {
        guard !readout.isDemo, (location.reading.speedKPH ?? 0) < 1 else { return false }
        return motion.calibrate()
    }

    func advance() {
        guard active else { return }
        let now = ProcessInfo.processInfo.systemUptime
        if let start = startedAnimationAt {
            startupProgress = min(1, max(0, (now - start) / 1.25))
            if startupProgress == 1 { startedAnimationAt = nil }
        }

        let dt = lastTick.map { min(0.5, max(0, now - $0)) } ?? 0.1
        lastTick = now
        var frame = readout
        if frame.isDemo {
            fillDemo(frame: &frame, dt: dt)
        } else {
            fillLive(frame: &frame, dt: dt)
        }
        let stopwatch = frame.isDemo ? demoStopwatch : liveStopwatch
        frame.stopwatchSeconds = stopwatch.elapsed(at: now)
        frame.stopwatchRunning = stopwatch.startedAt != nil
        if frame != readout { readout = frame }
    }

    private func fillDemo(frame: inout DashboardReadout, dt: TimeInterval) {
        demoElapsed += dt
        let demo = DemoTelemetry.sample(at: demoElapsed)
        let drive = demoPowertrain.update(speedKPH: demo.speedKPH,
                                          accelerationMPS2: demo.accelerationMPS2,
                                          dt: dt, profile: preferences.transmission)
        let temperatures = demoThermal.update(speedKPH: demo.speedKPH,
                                              accelerationMPS2: demo.accelerationMPS2,
                                              rpm: drive.rpm, dt: dt)
        demoTrip.update(speedKPH: demo.speedKPH, at: Date())
        demoPeak = max(demoPeak, hypot(demo.lateralG, demo.longitudinalG))
        frame.speedKPH = demo.speedKPH
        frame.rpm = drive.rpm
        frame.gearLabel = drive.gear.map(String.init) ?? "N"
        frame.coolantC = temperatures.engine
        frame.oilC = temperatures.oil
        frame.intakeC = temperatures.intake
        frame.longitudinalG = demo.longitudinalG
        frame.lateralG = demo.lateralG
        frame.peakG = demoPeak
        frame.gpsStatus = "VELOCIDADE SIMULADA"
        frame.gpsAccuracyMeters = nil
    }

    private func fillLive(frame: inout DashboardReadout, dt: TimeInterval) {
        let fix = location.reading
        let forces = motion.reading
        frame.speedKPH = fix.speedKPH
        frame.gpsAccuracyMeters = fix.accuracyMeters
        frame.gpsStatus = fix.status.label
        frame.longitudinalG = forces.longitudinalG
        frame.lateralG = forces.lateralG
        frame.peakG = forces.peakG

        let drive = livePowertrain.update(speedKPH: fix.speedKPH,
                                          accelerationMPS2: fix.accelerationMPS2,
                                          dt: dt, profile: preferences.transmission)
        guard let speed = fix.speedKPH else {
            frame.rpm = nil
            frame.gearLabel = nil
            return
        }

        let temperatures = liveThermal.update(speedKPH: speed,
                                              accelerationMPS2: fix.accelerationMPS2,
                                              rpm: drive.rpm, dt: dt)
        frame.rpm = drive.rpm
        frame.gearLabel = drive.gear.map(String.init) ?? "N"
        frame.coolantC = temperatures.engine
        frame.oilC = temperatures.oil
        frame.intakeC = temperatures.intake
    }

    private func recordLocation(_ reading: LocationReading) {
        guard active, !readout.isDemo else { return }
        guard let speed = reading.rawSpeedKPH, let timestamp = reading.timestamp else {
            if lastLiveFix != nil { breakLiveTripSegment() }
            return
        }
        guard timestamp != lastLiveFix else { return }
        liveTrip.update(speedKPH: speed, at: timestamp)
        lastLiveFix = timestamp
    }

    private func startSensors() {
        location.start()
        motion.start()
    }

    private func stopSensors() {
        location.stop()
        motion.stop()
        breakLiveTripSegment()
    }

    private func breakLiveTripSegment() {
        liveTrip.update(speedKPH: nil, at: Date())
        lastLiveFix = nil
    }

    private func clearLiveReadout() {
        livePowertrain = PowertrainModel()
        readout.speedKPH = nil
        readout.rpm = nil
        readout.gearLabel = nil
        readout.coolantC = 85
        readout.oilC = 85
        readout.intakeC = 30
        readout.gpsStatus = "AGUARDANDO GPS"
        readout.gpsAccuracyMeters = nil
        readout.longitudinalG = nil
        readout.lateralG = nil
        readout.peakG = 0
        updateStopwatch(at: ProcessInfo.processInfo.systemUptime)
    }

    private func updateStopwatch(at now: TimeInterval) {
        let stopwatch = readout.isDemo ? demoStopwatch : liveStopwatch
        readout.stopwatchSeconds = stopwatch.elapsed(at: now)
        readout.stopwatchRunning = stopwatch.startedAt != nil
    }
}
