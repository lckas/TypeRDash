import SwiftUI
import UIKit

@MainActor
struct SettingsView: View {
    @ObservedObject var model: DashboardModel
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @State private var calibrationFeedback: String?
    @State private var confirmingReset = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Toggle("Modo DEMO", isOn: Binding(
                        get: { model.readout.isDemo },
                        set: {
                            model.setDemo($0)
                            calibrationFeedback = nil
                        }
                    ))
                } footer: {
                    Text("Use o DEMO com o carro parado. Velocidade, temperaturas, força G e estatísticas do DEMO são simuladas.")
                }

                Section("Viagem") {
                    LabeledContent("Distância", value: model.trip.distanceKM.formatted(
                        .number.precision(.fractionLength(2))) + " km")
                    LabeledContent("Velocidade máxima", value: speed(model.trip.maxKPH))
                    LabeledContent("Velocidade média", value: speed(model.trip.averageKPH))
                    LabeledContent("Tempo em movimento", value: duration(model.trip.drivingTime))
                    Button("Zerar estatísticas", role: .destructive) { confirmingReset = true }
                }

                Section("Cronômetro") {
                    LabeledContent("Tempo", value: duration(model.readout.stopwatchSeconds))
                    Button(model.readout.stopwatchRunning ? "Pausar" : "Iniciar") {
                        model.toggleStopwatch()
                    }
                    Button("Zerar cronômetro") { model.resetStopwatch() }
                }

                Section("Painel") {
                    slider("Brilho da interface", value: binding(\.brightness), in: 0.35...1)
                    slider("Iluminação vermelha", value: binding(\.redIntensity), in: 0...1)
                    Toggle("Temperaturas simuladas", isOn: binding(\.showTemperatures))
                    Toggle("Animação ao abrir", isOn: binding(\.animateStartup))
                }

                Section {
                    NavigationLink("Relações, pneus e pontos de troca") {
                        TransmissionEditor(profile: model.preferences.transmission) { profile in
                            model.configure { $0.transmission = profile }
                        }
                    }
                    slider("Sensibilidade do RPM estimado", value: binding(\.transmission.rpmSensitivity),
                           in: 0.5...1.5)
                } header: {
                    Text("Simulação do câmbio")
                } footer: {
                    Text("O perfil de referência corresponde ao Civic EX 1998 manual. Confira pneus e transmissão do seu carro.")
                }

                Section {
                    LabeledContent("Sinal", value: model.readout.gpsStatus)
                    LabeledContent("Precisão horizontal",
                                   value: model.readout.gpsAccuracyMeters.map {
                                       "±" + $0.formatted(.number.precision(.fractionLength(0))) + " m"
                                   } ?? "—")
                    if !model.readout.isDemo {
                        Button("Abrir ajustes do iPhone") {
                            if let url = URL(string: UIApplication.openSettingsURLString) { openURL(url) }
                        }
                    }
                } header: {
                    Text("Localização")
                } footer: {
                    Text("No modo normal, permita a localização precisa durante o uso do app.")
                }

                Section {
                    LabeledContent("Calibração", value: model.isCalibrated ? "Salva" : "Pendente")
                    Button("Calibrar força G") {
                        let success = model.calibrateMotion()
                        calibrationFeedback = success
                            ? "Calibração salva."
                            : "Aguarde a leitura dos sensores com o iPhone montado e imóvel."
                    }
                    .disabled(model.readout.isDemo)
                    if let calibrationFeedback { Text(calibrationFeedback).foregroundStyle(.secondary) }
                } header: {
                    Text("Força G")
                } footer: {
                    Text("Fixe o iPhone na horizontal, com a traseira voltada para a frente do carro e a tela para a cabine. Calibre com o carro parado em piso plano. Repita se mudar o suporte.")
                }
            }
            .navigationTitle("Ajustes")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Concluir") { dismiss() }
                }
            }
            .confirmationDialog("Zerar estatísticas da viagem?", isPresented: $confirmingReset,
                                titleVisibility: .visible) {
                Button("Zerar estatísticas", role: .destructive) { model.resetStats() }
            }
        }
    }

    private func binding<Value>(_ keyPath: WritableKeyPath<DashboardPreferences, Value>) -> Binding<Value> {
        Binding(get: { model.preferences[keyPath: keyPath] },
                set: { value in model.configure { $0[keyPath: keyPath] = value } })
    }

    private func slider(_ title: String, value: Binding<Double>, in range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            LabeledContent(title, value: value.wrappedValue.formatted(.percent.precision(.fractionLength(0))))
            Slider(value: value, in: range, step: 0.05) { Text(title) }
        }
    }

    private func speed(_ kph: Double) -> String {
        kph.formatted(.number.precision(.fractionLength(1))) + " km/h"
    }

    private func duration(_ seconds: TimeInterval) -> String {
        let interval = max(0, Int(seconds))
        return String(format: "%02d:%02d:%02d", interval / 3600, interval / 60 % 60, interval % 60)
    }
}

private enum TransmissionField: Int, CaseIterable, Identifiable {
    case first, second, third, fourth, fifth, differential, width, aspect, wheel, limit, upshift, downshift

    var id: Self { self }

    var title: String {
        switch self {
        case .first, .second, .third, .fourth, .fifth: return "\(rawValue + 1)ª marcha"
        case .differential: return "Diferencial"
        case .width: return "Largura do pneu (mm)"
        case .aspect: return "Perfil do pneu (%)"
        case .wheel: return "Aro (pol.)"
        case .limit: return "Limite de rotação (RPM)"
        case .upshift: return "Subir sob carga (RPM)"
        case .downshift: return "Reduzir em ritmo constante (RPM)"
        }
    }

    var range: ClosedRange<Double> {
        switch self {
        case .first, .second, .third, .fourth, .fifth: return 0.4...6
        case .differential: return 2...6.5
        case .width: return 125...355
        case .aspect: return 20...90
        case .wheel: return 12...24
        case .limit: return 4500...8000
        case .upshift: return 2800...8000
        case .downshift: return 1000...2700
        }
    }

    func value(from profile: TransmissionProfile) -> Double {
        switch self {
        case .first, .second, .third, .fourth, .fifth: return profile.gearRatios[rawValue]
        case .differential: return profile.finalDrive
        case .width: return profile.tireWidthMM
        case .aspect: return profile.tireAspectPercent
        case .wheel: return profile.wheelDiameterInches
        case .limit: return profile.engineLimitRPM
        case .upshift: return profile.upshiftRPM
        case .downshift: return profile.downshiftRPM
        }
    }
}

private struct TransmissionEditor: View {
    let original: TransmissionProfile
    let onSave: (TransmissionProfile) -> Void

    @Environment(\.dismiss) private var dismiss
    @FocusState private var focusedField: TransmissionField?
    @State private var fields: [TransmissionField: String]

    init(profile: TransmissionProfile, onSave: @escaping (TransmissionProfile) -> Void) {
        original = profile
        self.onSave = onSave
        _fields = State(initialValue: Self.fields(for: profile))
    }

    var body: some View {
        Form {
            Section("Câmbio manual") {
                ForEach([TransmissionField.first, .second, .third, .fourth, .fifth, .differential]) { field in
                    input(field)
                }
            }
            Section("Medidas dos pneus") {
                ForEach([TransmissionField.width, .aspect, .wheel]) { field in input(field) }
            }
            Section("Rotação") {
                ForEach([TransmissionField.limit, .upshift, .downshift]) { field in input(field) }
            }
            Section {
                Button("Usar referência do Civic EX 1998") {
                    fields = Self.fields(for: .referenceUS)
                    focusedField = nil
                }
            } footer: {
                if validatedProfile == nil {
                    Text("Confira os valores. As relações devem diminuir da 1ª à 5ª. A rotação de subida deve ficar pelo menos 700 RPM acima da redução e até o limite.")
                        .foregroundStyle(.orange)
                }
            }
        }
        .navigationTitle("Transmissão")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("Salvar") {
                    guard let validatedProfile else { return }
                    onSave(validatedProfile)
                    dismiss()
                }
                .disabled(validatedProfile == nil)
            }
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("OK") { focusedField = nil }
            }
        }
    }

    private func input(_ field: TransmissionField) -> some View {
        let binding = Binding(get: { fields[field, default: ""] }, set: { fields[field] = $0 })
        return LabeledContent {
            TextField(field.title, text: binding)
                .keyboardType(.decimalPad)
                .multilineTextAlignment(.trailing)
                .foregroundStyle(number(field) == nil ? Color.orange : Color.primary)
                .focused($focusedField, equals: field)
                .accessibilityLabel(field.title)
        } label: {
            Text(field.title)
        }
    }

    private func number(_ field: TransmissionField) -> Double? {
        let input = fields[field, default: ""].trimmingCharacters(in: .whitespaces)
        guard let value = Double(input.replacingOccurrences(of: ",", with: ".")),
              field.range.contains(value) else { return nil }
        return value
    }

    private var validatedProfile: TransmissionProfile? {
        let ratios = [TransmissionField.first, .second, .third, .fourth, .fifth].compactMap(number)
        guard ratios.count == 5,
              zip(ratios, ratios.dropFirst()).allSatisfy({ $0.0 > $0.1 }),
              let differential = number(.differential),
              let width = number(.width), let aspect = number(.aspect), let wheel = number(.wheel),
              let limit = number(.limit), let upshift = number(.upshift), let downshift = number(.downshift),
              upshift <= limit, upshift - downshift >= 700 else { return nil }
        var profile = original
        profile.gearRatios = ratios
        profile.finalDrive = differential
        profile.tireWidthMM = width
        profile.tireAspectPercent = aspect
        profile.wheelDiameterInches = wheel
        profile.engineLimitRPM = limit
        profile.upshiftRPM = upshift
        profile.downshiftRPM = downshift
        return profile
    }

    private static func fields(for profile: TransmissionProfile) -> [TransmissionField: String] {
        Dictionary(uniqueKeysWithValues: TransmissionField.allCases.map { field in
            (field, field.value(from: profile).formatted(
                .number.grouping(.never).precision(.fractionLength(0...3)).locale(Locale(identifier: "pt_BR"))))
        })
    }
}
