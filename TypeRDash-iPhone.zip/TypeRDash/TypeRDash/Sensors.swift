import Combine
import CoreLocation
import CoreMotion
import Foundation
import simd

enum LocationStatus: Equatable {
    case inactive
    case authorizing
    case denied
    case restricted
    case preciseLocationDisabled
    case waiting
    case receiving
    case lowAccuracy
    case lost

    var label: String {
        switch self {
        case .inactive: "GPS INATIVO"
        case .authorizing: "AUTORIZAR GPS"
        case .denied: "GPS DESATIVADO"
        case .restricted: "GPS RESTRITO"
        case .preciseLocationDisabled: "ATIVE GPS PRECISO"
        case .waiting: "BUSCANDO GPS"
        case .receiving: "GPS ATIVO"
        case .lowAccuracy: "GPS IMPRECISO"
        case .lost: "SEM SINAL GPS"
        }
    }
}

struct LocationReading: Equatable {
    var speedKPH: Double?
    var rawSpeedKPH: Double?
    var accelerationMPS2 = 0.0
    var accuracyMeters: Double?
    var status: LocationStatus = .inactive
    var timestamp: Date?
}

@MainActor
final class LocationSensor: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published private(set) var reading = LocationReading()

    private let manager = CLLocationManager()
    private var filter = GPSFilter()
    private var isActive = false
    private var requestedAuthorization = false
    private var watchdog: Timer?
    private var startedReceivingAt: Date?

    private struct Fix: Sendable {
        let speed: Double
        let speedAccuracy: Double
        let horizontalAccuracy: Double
        let timestamp: Date

        init(_ location: CLLocation) {
            // Software-simulated fixes are invalid in the normal dashboard.
            speed = location.sourceInformation?.isSimulatedBySoftware == true ? -1 : location.speed
            speedAccuracy = location.speedAccuracy
            horizontalAccuracy = location.horizontalAccuracy
            timestamp = location.timestamp
        }
    }

    override init() {
        super.init()
        manager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        manager.distanceFilter = kCLDistanceFilterNone
        manager.activityType = .automotiveNavigation
        manager.pausesLocationUpdatesAutomatically = false
        manager.delegate = self
    }

    func start() {
        guard !isActive else { return }
        isActive = true
        updateAuthorization()
    }

    func stop() {
        isActive = false
        pauseLocationUpdates()
        setReading(LocationReading())
    }

    private func pauseLocationUpdates() {
        manager.stopUpdatingLocation()
        watchdog?.invalidate()
        watchdog = nil
        filter.reset()
        startedReceivingAt = nil
    }

    private func updateAuthorization() {
        guard isActive else { return }

        switch manager.authorizationStatus {
        case .notDetermined:
            pauseLocationUpdates()
            setReading(LocationReading(status: .authorizing))
            if !requestedAuthorization {
                requestedAuthorization = true
                manager.requestWhenInUseAuthorization()
            }
        case .restricted:
            pauseLocationUpdates()
            setReading(LocationReading(status: .restricted))
        case .denied:
            pauseLocationUpdates()
            setReading(LocationReading(status: .denied))
        case .authorizedAlways, .authorizedWhenInUse:
            guard manager.accuracyAuthorization == .fullAccuracy else {
                pauseLocationUpdates()
                setReading(LocationReading(status: .preciseLocationDisabled))
                return
            }
            guard watchdog == nil else { return }

            setReading(LocationReading(status: .waiting))
            startedReceivingAt = Date()
            manager.startUpdatingLocation()
            let timer = Timer(timeInterval: 0.25, repeats: true) { [weak self] _ in
                Task { @MainActor [weak self] in
                    self?.refresh()
                }
            }
            RunLoop.main.add(timer, forMode: .common)
            watchdog = timer
        @unknown default:
            pauseLocationUpdates()
            setReading(LocationReading(status: .lost))
        }
    }

    private func refresh() {
        guard isActive, let startedReceivingAt else { return }
        let now = Date()
        let fix = filter.reading(at: now)
        if fix.quality == .waiting,
           reading.status == .lost || now.timeIntervalSince(startedReceivingAt) >= 12 {
            setReading(LocationReading(status: .lost))
            return
        }
        publish(fix)
    }

    private func receive(_ fixes: [Fix]) {
        guard isActive, let startedReceivingAt else { return }

        let now = Date()
        // Core Location can first deliver a cached observation from before this session.
        for fix in fixes where fix.timestamp >= startedReceivingAt {
            let sample = GPSSample(
                speedMPS: fix.speed,
                speedAccuracyMPS: fix.speedAccuracy,
                horizontalAccuracyM: fix.horizontalAccuracy,
                timestamp: fix.timestamp
            )
            let output = filter.ingest(sample, at: now)
            if output.quality != .waiting { publish(output) }
        }
    }

    private func publish(_ fix: GPSReading) {
        let status: LocationStatus
        switch fix.quality {
        case .waiting: status = .waiting
        case .good: status = .receiving
        case .lowAccuracy: status = .lowAccuracy
        case .lost: status = .lost
        }

        setReading(LocationReading(
            speedKPH: fix.speedKPH,
            rawSpeedKPH: fix.rawSpeedKPH,
            accelerationMPS2: fix.accelerationMPS2,
            accuracyMeters: fix.horizontalAccuracyM,
            status: status,
            timestamp: fix.speedKPH != nil ? fix.timestamp : nil
        ))
    }

    private func setReading(_ next: LocationReading) {
        if next != reading { reading = next }
    }

    private func receiveError(denied: Bool) {
        guard isActive, watchdog != nil else { return }
        filter.reset()
        setReading(LocationReading(status: denied ? .denied : .lost))
        if denied { updateAuthorization() }
    }

    nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        Task { @MainActor [weak self] in
            self?.updateAuthorization()
        }
    }

    nonisolated func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let fixes = locations.map(Fix.init)
        Task { @MainActor [weak self] in
            self?.receive(fixes)
        }
    }

    nonisolated func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        let denied = (error as? CLError)?.code == .denied
        Task { @MainActor [weak self] in
            self?.receiveError(denied: denied)
        }
    }
}

struct MotionReading: Equatable {
    var longitudinalG: Double?
    var lateralG: Double?
    var peakG = 0.0
}

@MainActor
final class MotionSensor: ObservableObject {
    @Published private(set) var reading = MotionReading()
    @Published private(set) var isCalibrated = false

    private let manager = CMMotionManager()
    private let defaults: UserDefaults
    private let calibrationKey = "typeRDash.motion.zero"
    private var calibrationBias = SIMD3<Double>.zero
    private var isActive = false
    private var generation = 0
    private var watchdog: Timer?
    private var latestTime: TimeInterval?
    private var stillSince: TimeInterval?
    private var stillAverage = SIMD3<Double>.zero

    private struct MotionSample: Sendable {
        let acceleration: SIMD3<Double>
        let gravity: SIMD3<Double>
        let timestamp: TimeInterval

        init(_ motion: CMDeviceMotion) {
            let a = motion.userAcceleration
            let g = motion.gravity
            acceleration = SIMD3(a.x, a.y, a.z)
            gravity = SIMD3(g.x, g.y, g.z)
            timestamp = motion.timestamp
        }
    }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        if let values = defaults.array(forKey: calibrationKey) as? [Double],
           values.count == 3, values.allSatisfy({ $0.isFinite && abs($0) <= 0.055 }) {
            calibrationBias = SIMD3(values[0], values[1], values[2])
            isCalibrated = true
        }
    }

    func start() {
        guard !isActive, manager.isDeviceMotionAvailable else { return }
        isActive = true
        generation += 1
        let currentGeneration = generation
        manager.deviceMotionUpdateInterval = 1.0 / 30.0
        manager.startDeviceMotionUpdates(using: .xArbitraryZVertical, to: .main) { [weak self] motion, _ in
            let sample = motion.map(MotionSample.init)
            Task { @MainActor [weak self] in
                guard let self, self.isActive, self.generation == currentGeneration else { return }
                if let sample {
                    self.receive(sample)
                } else {
                    self.clearSample()
                }
            }
        }

        let timer = Timer(timeInterval: 0.5, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, let latestTime = self.latestTime else { return }
                if ProcessInfo.processInfo.systemUptime - latestTime > 1 {
                    self.clearSample()
                }
            }
        }
        RunLoop.main.add(timer, forMode: .common)
        watchdog = timer
    }

    func stop() {
        isActive = false
        manager.stopDeviceMotionUpdates()
        watchdog?.invalidate()
        watchdog = nil
        clearSample()
    }

    @discardableResult
    func calibrate() -> Bool {
        guard
            isActive,
            let latestTime,
            ProcessInfo.processInfo.systemUptime - latestTime <= 0.3,
            let stillSince, latestTime - stillSince >= 0.5,
            reading.longitudinalG != nil
        else { return false }

        calibrationBias = stillAverage
        defaults.set([stillAverage.x, stillAverage.y, stillAverage.z], forKey: calibrationKey)
        isCalibrated = true
        reading = MotionReading(longitudinalG: 0, lateralG: 0, peakG: reading.peakG)
        return true
    }

    func resetPeak() {
        reading = MotionReading(longitudinalG: reading.longitudinalG, lateralG: reading.lateralG)
    }

    private func receive(_ sample: MotionSample) {
        let gravityMagnitude = simd_length(sample.gravity)
        let movement = simd_length(sample.acceleration)
        guard movement.isFinite, gravityMagnitude.isFinite, gravityMagnitude > 0.5 else {
            clearSample()
            return
        }

        let up = -sample.gravity / gravityMagnitude
        // The phone's back points toward the hood. Gravity levels both axes even when tilted.
        let rearNormal = SIMD3<Double>(0, 0, -1)
        let horizontalForward = rearNormal - simd_dot(rearNormal, up) * up
        guard simd_length(horizontalForward) >= 0.5 else {
            clearSample()
            return
        }

        let forward = simd_normalize(horizontalForward)
        let right = simd_cross(forward, up)
        let acceleration = sample.acceleration - calibrationBias
        let longitudinal = simd_dot(acceleration, forward)
        let lateral = simd_dot(acceleration, right)

        if movement < 0.055 {
            if stillSince == nil {
                stillSince = sample.timestamp
                stillAverage = sample.acceleration
            } else {
                stillAverage += 0.12 * (sample.acceleration - stillAverage)
            }
        } else {
            stillSince = nil
        }

        let dt = latestTime.map { sample.timestamp - $0 } ?? 0
        let fraction = dt > 0 && dt < 0.3 ? 1 - exp(-dt / 0.14) : 1
        let previousLongitudinal = reading.longitudinalG ?? longitudinal
        let previousLateral = reading.lateralG ?? lateral
        let filteredLongitudinal = previousLongitudinal + fraction * (longitudinal - previousLongitudinal)
        let filteredLateral = previousLateral + fraction * (lateral - previousLateral)
        latestTime = sample.timestamp
        reading = MotionReading(
            longitudinalG: filteredLongitudinal,
            lateralG: filteredLateral,
            peakG: max(reading.peakG, hypot(filteredLongitudinal, filteredLateral))
        )
    }

    private func clearSample() {
        latestTime = nil
        stillSince = nil
        stillAverage = .zero
        let next = MotionReading(peakG: reading.peakG)
        if next != reading { reading = next }
    }
}
