import Foundation

enum GPSQuality: Equatable {
    case waiting
    case good
    case lowAccuracy
    case lost
}

struct GPSSample {
    var speedMPS: Double
    var speedAccuracyMPS: Double
    var horizontalAccuracyM: Double
    var timestamp: Date
}

struct GPSReading: Equatable {
    var speedKPH: Double?
    var rawSpeedKPH: Double?
    var accelerationMPS2 = 0.0
    var horizontalAccuracyM: Double?
    var timestamp: Date?
    var quality: GPSQuality = .waiting
}

struct GPSFilter {
    static let maximumAge = 2.5
    private var current = GPSReading()
    private var lastTimestamp: Date?
    private var moving = false

    mutating func ingest(_ sample: GPSSample, at now: Date) -> GPSReading {
        _ = reading(at: now)
        let age = now.timeIntervalSince(sample.timestamp)
        // Delayed callbacks and reordered batches cannot replace a newer observation.
        guard age.isFinite, age >= -0.5, age < Self.maximumAge,
              lastTimestamp.map({ sample.timestamp > $0 }) ?? true else { return current }
        lastTimestamp = sample.timestamp

        let horizontalAccuracy = sample.horizontalAccuracyM
        let hasPositionAccuracy = horizontalAccuracy.isFinite && horizontalAccuracy >= 0
        guard hasPositionAccuracy, horizontalAccuracy <= 30,
              sample.speedAccuracyMPS.isFinite, (0...1.5).contains(sample.speedAccuracyMPS),
              (0...125).contains(sample.speedMPS) else {
            moving = false
            current = GPSReading(
                horizontalAccuracyM: hasPositionAccuracy ? horizontalAccuracy : nil,
                timestamp: sample.timestamp,
                quality: .lowAccuracy
            )
            return current
        }

        // Separate enter/exit thresholds avoid GPS drift toggling zero at a standstill.
        moving = sample.speedMPS > (moving ? 0.45 : 0.65)
        let rawSpeedMPS = moving ? sample.speedMPS : 0
        var smoothedSpeedMPS = rawSpeedMPS
        var acceleration = 0.0
        if let previousSpeed = current.speedKPH, let previousRawSpeed = current.rawSpeedKPH,
           let previousTime = current.timestamp {
            let dt = sample.timestamp.timeIntervalSince(previousTime)
            if moving {
                let weight = max(0.55, 1 - exp(-dt / 0.22))
                smoothedSpeedMPS = previousSpeed / 3.6 + (rawSpeedMPS - previousSpeed / 3.6) * weight
            }
            let derivative = min(6, max(-8, (rawSpeedMPS - previousRawSpeed / 3.6) / dt))
            let accelerationWeight = 1 - exp(-dt / 0.6)
            acceleration = current.accelerationMPS2 + (derivative - current.accelerationMPS2) * accelerationWeight
        }
        current = GPSReading(
            speedKPH: smoothedSpeedMPS * 3.6,
            rawSpeedKPH: rawSpeedMPS * 3.6,
            accelerationMPS2: acceleration,
            horizontalAccuracyM: horizontalAccuracy,
            timestamp: sample.timestamp,
            quality: .good
        )
        return current
    }

    mutating func reading(at now: Date) -> GPSReading {
        if let lastTimestamp, now.timeIntervalSince(lastTimestamp) >= Self.maximumAge {
            moving = false
            current = GPSReading(quality: .lost)
        }
        return current
    }

    mutating func reset() {
        self = GPSFilter()
    }
}
