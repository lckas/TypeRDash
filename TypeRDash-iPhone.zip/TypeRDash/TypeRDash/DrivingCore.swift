import Foundation

struct TransmissionProfile: Codable, Equatable {
    // BR/US Civic EX 1998 manual gearing and tires. The D16Y8 fuel-cut
    // reference comes from the U.S. workshop manual.
    static let referenceUS = TransmissionProfile()

    var gearRatios = [3.250, 1.909, 1.250, 0.909, 0.702]
    var finalDrive = 4.250
    var tireWidthMM = 185.0
    var tireAspectPercent = 65.0
    var wheelDiameterInches = 14.0
    var engineLimitRPM = 7_000.0
    var upshiftRPM = 5_800.0
    var downshiftRPM = 1_750.0
    var rpmSensitivity = 1.0

    var tireDiameterM: Double {
        let width = Self.checked(tireWidthMM, in: 125...355, fallback: 185)
        let aspect = Self.checked(tireAspectPercent, in: 20...90, fallback: 65)
        let wheel = Self.checked(wheelDiameterInches, in: 12...24, fallback: 14)
        return wheel * 0.0254 + 2 * width * aspect / 100_000
    }

    func coupledRPM(speedKPH: Double, gear: Int) -> Double {
        guard speedKPH.isFinite, speedKPH > 0, (1...5).contains(gear) else { return 0 }
        let wheelRPM = (speedKPH / 3.6) / (Double.pi * tireDiameterM) * 60
        let fallbackRatios = Self.referenceUS.gearRatios
        let ratiosUsable = gearRatios.count == 5
            && gearRatios.allSatisfy { (0.4...6.0).contains($0) }
            && zip(gearRatios, gearRatios.dropFirst()).allSatisfy { $0.0 > $0.1 }
        let ratio = (ratiosUsable ? gearRatios : fallbackRatios)[gear - 1]
        return wheelRPM * ratio * Self.checked(finalDrive, in: 2...6.5, fallback: 4.250)
    }

    fileprivate var safeEngineLimit: Double {
        Self.checked(engineLimitRPM, in: 4_500...8_000, fallback: 7_000)
    }

    fileprivate var safeUpshiftRPM: Double {
        Self.checked(
            upshiftRPM,
            in: 2_800...safeEngineLimit,
            fallback: min(5_800, safeEngineLimit)
        )
    }

    fileprivate var safeDownshiftRPM: Double {
        let upperBound = min(2_700, safeUpshiftRPM - 700)
        return Self.checked(downshiftRPM, in: 1_000...upperBound, fallback: 1_750)
    }

    fileprivate var safeSensitivity: Double {
        Self.checked(rpmSensitivity, in: 0.5...1.5, fallback: 1)
    }

    private static func checked(_ value: Double, in bounds: ClosedRange<Double>, fallback: Double) -> Double {
        value.isFinite ? min(max(value, bounds.lowerBound), bounds.upperBound) : fallback
    }
}

struct PowertrainReadout: Equatable {
    var rpm: Double
    var gear: Int?
}

struct PowertrainModel {
    private(set) var rpm = 825.0
    private(set) var gear: Int?
    private var timeSinceShift = 2.0

    mutating func update(
        speedKPH: Double?,
        accelerationMPS2: Double,
        dt: Double,
        profile: TransmissionProfile
    ) -> PowertrainReadout {
        let step = limited(dt, to: 0...1)
        let acceleration = limited(accelerationMPS2, to: -8...5)
        let sensitivity = profile.safeSensitivity
        let throttle = limited(acceleration * sensitivity / 2.4, to: 0...1)
        let coast = limited(-acceleration / 2.5, to: 0...1)
        timeSinceShift = min(timeSinceShift + step, 3)

        let speed = limited(speedKPH ?? 0, to: 0...400)
        let neutralThreshold = gear == nil ? 3.4 : 2.1
        guard speed >= neutralThreshold else {
            gear = nil
            rpm = approach(rpm, 825, by: step, timeConstant: 0.16)
            return PowertrainReadout(rpm: rpm, gear: nil)
        }

        let downshiftPoint = profile.safeDownshiftRPM
        // Braking calls for an earlier downshift to emulate engine braking.
        let brakingDownshiftPoint = downshiftPoint + coast * 430
        let upshiftUnderLoad = profile.safeUpshiftRPM
        let coastShiftOffset = min(1_900, upshiftUnderLoad - downshiftPoint - 400)
        let upshiftPoint = upshiftUnderLoad - coastShiftOffset * (1 - throttle)

        if let current = gear {
            if timeSinceShift >= 0.85 {
                let currentRPM = profile.coupledRPM(speedKPH: speed, gear: current)
                let lowerGearRPM = profile.coupledRPM(speedKPH: speed, gear: current - 1)
                let higherGearRPM = profile.coupledRPM(speedKPH: speed, gear: current + 1)
                // A margin between shift points prevents hunting near a boundary.
                if current < 5, currentRPM >= upshiftPoint,
                   higherGearRPM > downshiftPoint + 220 {
                    shift(to: current + 1)
                } else if current > 1, currentRPM < brakingDownshiftPoint,
                          lowerGearRPM < upshiftPoint - 280 {
                    shift(to: current - 1)
                }
            }
        } else {
            // When a GPS fix arrives while moving, engage a plausible gear directly.
            gear = (1...5).first {
                profile.coupledRPM(speedKPH: speed, gear: $0) < upshiftPoint
            } ?? 5
            timeSinceShift = 0.85
        }

        guard let gear else { return PowertrainReadout(rpm: rpm, gear: nil) }
        let coupled = profile.coupledRPM(speedKPH: speed, gear: gear)
        let clutchSlip = gear == 1 ? max(0, 1 - speed / 18) * throttle * 1_150 : 0
        let shiftDip = max(0, 1 - timeSinceShift / 0.27) * 260
        let target = limited(coupled + clutchSlip - shiftDip, to: 825...profile.safeEngineLimit)
        rpm = limited(
            approach(rpm, target, by: step, timeConstant: 0.18 / sensitivity),
            to: 825...profile.safeEngineLimit
        )
        return PowertrainReadout(rpm: rpm, gear: gear)
    }

    private mutating func shift(to gear: Int) {
        self.gear = gear
        timeSinceShift = 0
    }
}

struct TemperatureReadout: Equatable {
    var engine: Double = 87
    var oil: Double = 87
    var intake: Double = 34
}

struct ThermalModel {
    private(set) var temperatures = TemperatureReadout()
    private var sustainedLoad = 0.0

    mutating func update(speedKPH: Double, accelerationMPS2: Double, rpm: Double, dt: Double) -> TemperatureReadout {
        let step = limited(dt, to: 0...1)
        let acceleration = limited(accelerationMPS2, to: -8...6)
        let loadFromAcceleration = limited(acceleration / 2.2, to: 0...1)
        let loadFromRPM = limited((rpm - 1_800) / 4_000, to: 0...1)
        let load = limited(loadFromAcceleration * 0.72 + loadFromRPM * 0.45 + min(0, acceleration) * 0.11, to: 0...1)
        sustainedLoad = approach(sustainedLoad, load, by: step, timeConstant: load > sustainedLoad ? 14 : 25)
        let airflow = limited(speedKPH / 130, to: 0...1)
        let targets = TemperatureReadout(
            engine: 88 + sustainedLoad * 8 - airflow * 0.8,
            oil: 92 + sustainedLoad * 16 - airflow * 1.4,
            intake: 37 + sustainedLoad * 13 - airflow * 5
        )
        temperatures.engine = approach(temperatures.engine, min(targets.engine, 96), by: step, timeConstant: 45)
        temperatures.oil = approach(temperatures.oil, min(targets.oil, 108), by: step, timeConstant: 68)
        temperatures.intake = approach(temperatures.intake, min(targets.intake, 50), by: step, timeConstant: 19)
        return temperatures
    }
}

struct TripAccumulator {
    private(set) var distanceKM = 0.0
    private(set) var maxKPH = 0.0
    private(set) var drivingTime = 0.0
    private var previous: (speedKPH: Double, time: Date)?

    var averageKPH: Double {
        drivingTime > 0 ? distanceKM * 3_600 / drivingTime : 0
    }

    mutating func update(speedKPH: Double?, at time: Date) {
        guard let speedKPH, speedKPH.isFinite, speedKPH >= 0 else {
            // Leave gaps unmeasured when the GPS loses its fix or the app pauses.
            previous = nil
            return
        }
        if let previous {
            let interval = time.timeIntervalSince(previous.time)
            guard interval > 0 else { return }
            if interval <= 3, max(speedKPH, previous.speedKPH) > 0 {
                let segmentAverage = (previous.speedKPH + speedKPH) * 0.5
                distanceKM += segmentAverage * interval / 3_600
                drivingTime += interval
            }
        }
        maxKPH = max(maxKPH, speedKPH)
        previous = (speedKPH, time)
    }

    mutating func reset() {
        self = TripAccumulator()
    }
}

struct DemoReading: Equatable {
    var speedKPH: Double
    var accelerationMPS2: Double
    var lateralG: Double
    var longitudinalG: Double
}

enum DemoTelemetry {
    private static let route: [(seconds: Double, speedKPH: Double)] = [
        (0, 0), (2, 0), (10, 54), (18, 108), (27, 132),
        (34, 132), (40, 54), (49, 70), (57, 70), (65, 0), (69, 0)
    ]

    static func sample(at elapsed: TimeInterval) -> DemoReading {
        let time = (elapsed.isFinite ? max(0, elapsed) : 0).truncatingRemainder(dividingBy: 69)
        let upperIndex = route.firstIndex { $0.seconds > time } ?? route.count - 1
        let lower = route[upperIndex - 1]
        let upper = route[upperIndex]
        let duration = upper.seconds - lower.seconds
        let fraction = (time - lower.seconds) / duration
        let interpolation = fraction * fraction * (3 - 2 * fraction)
        let change = upper.speedKPH - lower.speedKPH
        let speed = lower.speedKPH + change * interpolation
        let acceleration = change * 6 * fraction * (1 - fraction) / duration / 3.6
        let lateral = 0.5 * pow(sin(time * .pi / 19), 3) * min(speed / 60, 1)
        return DemoReading(speedKPH: speed, accelerationMPS2: acceleration, lateralG: lateral, longitudinalG: acceleration / 9.80665)
    }
}

private func limited(_ value: Double, to bounds: ClosedRange<Double>) -> Double {
    value.isFinite ? min(max(value, bounds.lowerBound), bounds.upperBound) : bounds.lowerBound
}

private func approach(_ value: Double, _ target: Double, by step: Double, timeConstant: Double) -> Double {
    value + (target - value) * (1 - exp(-step / timeConstant))
}
