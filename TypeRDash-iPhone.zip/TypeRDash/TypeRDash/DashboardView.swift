import Foundation
import SwiftUI

struct DashboardReadout: Equatable {
    var speedKPH: Double?
    var rpm: Double?
    var gearLabel: String?
    var coolantC: Double
    var oilC: Double
    var intakeC: Double
    var longitudinalG: Double?
    var lateralG: Double?
    var peakG: Double
    var gpsStatus: String
    var gpsAccuracyMeters: Double?
    var stopwatchSeconds: Double
    var stopwatchRunning: Bool
    var isDemo: Bool
}

struct DashboardView: View {
    let readout: DashboardReadout
    let brightness: Double
    let redIntensity: Double
    let showTemperatures: Bool
    let startupProgress: Double
    let onSettings: () -> Void
    let onStopwatch: () -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private var startupRPM: Double {
        guard startupProgress < 1, !reduceMotion else { return readout.rpm ?? 0 }
        let sweep = min(max((startupProgress - 0.05) / 0.88, 0), 1)
        return sin(.pi * sweep) * 8_000
    }

    private var startupVisibility: Double {
        reduceMotion ? 1 : min(1, 0.48 + startupProgress * 1.1)
    }

    private var illumination: Double {
        let fraction = min(max((startupRPM - 3_500) / 4_500, 0), 1)
        return (0.32 + fraction * 0.68) * min(max(redIntensity, 0), 1)
    }

    var body: some View {
        GeometryReader { geometry in
            let available = geometry.size
            let scale = max(0.01, min(available.width / 700, available.height / 350))
            let width = available.width / scale
            let height = available.height / scale

            layout(width: width, height: height, buttonSize: max(48, 44 / scale))
                .scaleEffect(scale)
                .frame(width: available.width, height: available.height)
        }
        .background(CarbonWeave().equatable().ignoresSafeArea())
        .preferredColorScheme(.dark)
        .persistentSystemOverlays(.hidden)
    }

    private func layout(width: CGFloat, height: CGFloat, buttonSize: CGFloat) -> some View {
        let lowerY = height - 54
        let gearY = min(height * 0.54, lowerY - 113)
        let tachWidth = width * 0.73 - 24
        let speedWidth = width * 0.25 - 12

        return ZStack(alignment: .topLeading) {
            HStack(spacing: 9) {
                Capsule()
                    .fill(DashColor.red)
                    .frame(width: 3, height: 22)
                    .rotationEffect(.degrees(16))
                Text("+R")
                    .font(.system(size: 27, weight: .black))
                    .italic()
                    .tracking(-1.6)
                    .foregroundStyle(DashColor.red)
                    .accessibilityLabel("Modo mais R")
            }
            .position(x: 55, y: 29)

            if readout.isDemo {
                Text("DEMO")
                    .font(.system(size: 13, weight: .black, design: .monospaced))
                    .tracking(2)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 4)
                    .foregroundStyle(.black)
                    .background(DashColor.amber, in: Capsule())
                    .position(x: width / 2, y: 28)
                    .accessibilityLabel("Modo de demonstração ativo")
            }

            Button(action: onSettings) {
                Image(systemName: "gearshape")
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(DashColor.ink)
                    .frame(width: buttonSize, height: buttonSize)
                    .background {
                        Circle()
                            .strokeBorder(.white.opacity(0.15), lineWidth: 1)
                            .padding(6)
                    }
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .position(x: width - 37, y: 28)
            .accessibilityLabel("Configurações")

            ZStack(alignment: .topTrailing) {
                RevScale(rpm: startupRPM, redIntensity: redIntensity)
                    .animation(
                        startupProgress == 1 && !reduceMotion ? .easeOut(duration: 0.12) : nil,
                        value: startupRPM
                    )
                    .accessibilityHidden(true)

                Text(readout.rpm.map { "\(whole($0)) RPM EST." } ?? "— RPM EST.")
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .tracking(0.7)
                    .foregroundStyle(DashColor.muted)
                    .padding(.trailing, 14)
                    .accessibilityLabel(Text(readout.rpm.map {
                        "Rotação estimada de \(whole($0)) rotações por minuto"
                    } ?? "Rotação estimada indisponível"))
            }
            .frame(width: tachWidth, height: 103)
            .position(x: 20 + tachWidth / 2, y: 103)

            gear
                .frame(width: width - 32, height: 113)
                .position(x: width / 2, y: gearY)

            speed
                .frame(width: speedWidth)
                .position(x: width * 0.859, y: 115)

            Rectangle()
                .fill(.white.opacity(0.12))
                .frame(width: width - 56, height: 1)
                .position(x: width / 2, y: height - 108)
                .accessibilityHidden(true)

            HStack(spacing: 0) {
                stopwatch(buttonSize: buttonSize)
                    .frame(width: width * 0.22)
                divider
                Group {
                    if showTemperatures {
                        temperatures
                    } else {
                        Spacer(minLength: 0)
                    }
                }
                .frame(maxWidth: .infinity)
                divider
                ForcesView(
                    longitudinal: readout.longitudinalG,
                    lateral: readout.lateralG,
                    peak: readout.peakG
                )
                .frame(width: width * 0.245)
            }
            .frame(width: width - 40, height: 92)
            .position(x: width / 2, y: lowerY)
        }
        .frame(width: width, height: height)
        .opacity(min(max(brightness, 0.3), 1) * startupVisibility)
    }

    private var speed: some View {
        VStack(spacing: 0) {
            Group {
                if let speed = readout.speedKPH, speed > 0 {
                    SpeedDigits(speed: speed)
                        .animation(reduceMotion ? nil : .linear(duration: 0.18), value: speed)
                } else {
                    Text(readout.speedKPH == nil ? "—" : "0")
                }
            }
                .font(.system(size: 79, weight: .heavy, design: .monospaced))
                .monospacedDigit()
                .tracking(-7)
                .foregroundStyle(DashColor.ink)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
                .padding(.trailing, 6)
                .accessibilityLabel(Text(readout.speedKPH.map {
                    "Velocidade de \(whole($0)) quilômetros por hora"
                } ?? "Velocidade indisponível"))

            Text("km/h")
                .font(.system(size: 15, weight: .semibold, design: .monospaced))
                .foregroundStyle(DashColor.muted)
                .accessibilityHidden(true)

            VStack(spacing: 3) {
                HStack(spacing: 5) {
                    Circle()
                        .fill(readout.isDemo || readout.speedKPH == nil ? DashColor.amber : DashColor.mint)
                        .frame(width: 5, height: 5)
                        .accessibilityHidden(true)
                    Text(readout.isDemo ? "VELOCIDADE SIM" : readout.gpsStatus)
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                }
                if !readout.isDemo, let accuracy = readout.gpsAccuracyMeters {
                    Text("±\(whole(accuracy)) m")
                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                        .monospacedDigit()
                        .foregroundStyle(DashColor.muted)
                        .accessibilityLabel("Precisão horizontal de \(whole(accuracy)) metros")
                }
            }
            .foregroundStyle(readout.isDemo || readout.speedKPH == nil ? DashColor.amber : DashColor.mint)
            .padding(.top, 7)
        }
    }

    private var gear: some View {
        ZStack {
            GearSurround(illumination: illumination)
                .accessibilityHidden(true)

            VStack(spacing: -3) {
                Text(readout.gearLabel ?? "—")
                    .font(.system(size: 75, weight: .heavy, design: .monospaced))
                    .foregroundStyle(DashColor.ink)
                    .shadow(color: DashColor.red.opacity(illumination * 0.5), radius: 12)
                    .lineLimit(1)
                Text("MARCHA EST.")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .tracking(1.1)
                    .foregroundStyle(DashColor.muted)
            }
            .padding(.bottom, 7)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(Text(gearAccessibilityLabel))
        .allowsHitTesting(false)
    }

    private var gearAccessibilityLabel: String {
        switch readout.gearLabel {
        case "N": return "Marcha estimada em ponto morto"
        case let label?: return "Marcha estimada \(label)"
        case nil: return "Marcha estimada indisponível"
        }
    }

    private func stopwatch(buttonSize: CGFloat) -> some View {
        Button(action: onStopwatch) {
            VStack(alignment: .leading, spacing: 5) {
                Text("CRONÔMETRO")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .tracking(0.8)
                    .foregroundStyle(DashColor.muted)

                HStack(spacing: 9) {
                    Text(stopwatchText)
                        .font(.system(size: 23, weight: .bold, design: .monospaced))
                        .monospacedDigit()
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                    Image(systemName: readout.stopwatchRunning ? "pause.fill" : "play.fill")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundStyle(readout.stopwatchRunning ? DashColor.amber : DashColor.muted)
                }
                .foregroundStyle(DashColor.ink)
            }
            .frame(maxWidth: .infinity, minHeight: buttonSize)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(Text(readout.stopwatchRunning ? "Pausar cronômetro" : "Iniciar cronômetro"))
        .accessibilityValue(Text(stopwatchText))
    }

    private var stopwatchText: String {
        let seconds = Int(min(max(readout.stopwatchSeconds, 0), 359_999))
        if seconds >= 3_600 {
            return String(format: "%d:%02d:%02d", seconds / 3_600, seconds / 60 % 60, seconds % 60)
        }
        let tenths = Int(min(max(readout.stopwatchSeconds, 0), 3_600) * 10) % 10
        return String(format: "%02d:%02d.%d", seconds / 60, seconds % 60, tenths)
    }

    private var divider: some View {
        Rectangle()
            .fill(.white.opacity(0.13))
            .frame(width: 1, height: 49)
            .accessibilityHidden(true)
    }

    private var temperatures: some View {
        VStack(spacing: 6) {
            HStack(spacing: 6) {
                Text("TEMPERATURAS")
                    .tracking(0.9)
                    .foregroundStyle(DashColor.muted)
                Text("SIM")
                    .tracking(0.5)
                    .foregroundStyle(DashColor.amber)
                    .padding(.horizontal, 4)
                    .padding(.vertical, 1)
                    .background(DashColor.amber.opacity(0.13), in: RoundedRectangle(cornerRadius: 2))
            }
            .font(.system(size: 10, weight: .bold, design: .monospaced))
            .accessibilityLabel("Temperaturas simuladas")

            HStack(spacing: 8) {
                temperature("MOTOR", value: readout.coolantC)
                temperature("ÓLEO", value: readout.oilC)
                temperature("ADMISSÃO", value: readout.intakeC)
            }
            .padding(.horizontal, 10)
        }
    }

    private func temperature(_ title: String, value: Double) -> some View {
        VStack(spacing: 2) {
            Text(title)
                .font(.system(size: 9, weight: .semibold, design: .monospaced))
                .tracking(0.4)
                .foregroundStyle(DashColor.muted)
            HStack(alignment: .firstTextBaseline, spacing: 1) {
                Text(whole(value))
                    .font(.system(size: 24, weight: .bold, design: .monospaced))
                    .monospacedDigit()
                Text("°C")
                    .font(.system(size: 11, weight: .semibold, design: .monospaced))
                    .foregroundStyle(DashColor.muted)
            }
            .foregroundStyle(DashColor.ink)
            .lineLimit(1)
            .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(title), \(whole(value)) graus Celsius, simulado")
    }

    private func whole(_ value: Double) -> String {
        value.isFinite ? String(format: "%.0f", value) : "—"
    }
}

private struct SpeedDigits: View, Animatable {
    var speed: Double

    var animatableData: Double {
        get { speed }
        set { speed = newValue }
    }

    var body: some View {
        Text(String(format: "%.0f", speed))
    }
}

private enum DashColor {
    static let ink = Color(red: 0.97, green: 0.97, blue: 0.98)
    static let muted = Color(red: 0.67, green: 0.70, blue: 0.75)
    static let red = Color(red: 1, green: 0.17, blue: 0.23)
    static let amber = Color(red: 1, green: 0.63, blue: 0.26)
    static let mint = Color(red: 0.54, green: 0.87, blue: 0.70)
}

private struct CarbonWeave: View, Equatable {
    var body: some View {
        Canvas(opaque: true, rendersAsynchronously: true) { context, size in
            let rect = CGRect(origin: .zero, size: size)
            let step: CGFloat = 8
            var weave = Path()
            var filaments = Path()
            for row in 0..<Int(ceil(size.height / step)) {
                for column in 0..<Int(ceil(size.width / step)) {
                    let x = CGFloat(column) * step
                    let y = CGFloat(row) * step
                    if (column + row) % 2 == 0 {
                        weave.addRect(CGRect(x: x, y: y, width: step, height: step))
                        filaments.addRect(CGRect(x: x + 0.5, y: y + 1, width: step - 1, height: 1))
                    } else {
                        filaments.addRect(CGRect(x: x + 1, y: y + 0.5, width: 1, height: step - 1))
                    }
                }
            }

            context.fill(Path(rect), with: .color(Color(white: 0.036)))
            context.fill(weave, with: .color(.white.opacity(0.016)))
            context.fill(filaments, with: .color(.white.opacity(0.013)))
            context.fill(
                Path(rect),
                with: .radialGradient(
                    Gradient(colors: [.clear, .black.opacity(0.72)]),
                    center: CGPoint(x: size.width / 2, y: size.height * 0.40),
                    startRadius: size.height * 0.13,
                    endRadius: size.width * 0.61
                )
            )
        }
        .accessibilityHidden(true)
    }
}

private struct RevScale: View, Animatable {
    var rpm: Double
    let redIntensity: Double

    var animatableData: Double {
        get { rpm }
        set { rpm = newValue }
    }

    var body: some View {
        Canvas { context, size in
            let left: CGFloat = 13
            let right = size.width - 13
            let maxRPM = 8_000.0
            let redline = 7_000.0
            let value = rpm.isFinite ? min(max(rpm, 0), maxRPM) : 0
            let intensity = min(max(redIntensity, 0), 1)

            func point(_ rpm: Double) -> CGPoint {
                let fraction = CGFloat(rpm / maxRPM)
                let bend = min(max(fraction / 0.39, 0), 1)
                let rise = 1 - pow(1 - bend, 3)
                return CGPoint(x: left + (right - left) * fraction, y: 68 - 33 * rise - 3 * fraction)
            }

            func segment(_ start: Double, _ end: Double) -> Path {
                var path = Path()
                path.move(to: point(start))
                for step in 1...48 {
                    path.addLine(to: point(start + (end - start) * Double(step) / 48))
                }
                return path
            }

            func offset(_ point: CGPoint, by offsetY: CGFloat) -> CGPoint {
                CGPoint(x: point.x, y: point.y + offsetY)
            }

            context.stroke(segment(0, maxRPM), with: .color(.black.opacity(0.8)), lineWidth: 17)
            context.stroke(segment(0, maxRPM), with: .color(.white.opacity(0.085)), lineWidth: 13)
            context.stroke(segment(redline, maxRPM), with: .color(DashColor.red.opacity(0.36)), lineWidth: 13)

            if value > 0 {
                let active = segment(0, value)
                context.stroke(
                    active,
                    with: .linearGradient(
                        Gradient(stops: [
                            .init(color: DashColor.ink, location: 0),
                            .init(color: .white, location: 0.51),
                            .init(color: DashColor.amber, location: 0.79),
                            .init(color: DashColor.red, location: 0.89),
                            .init(color: DashColor.red, location: 1)
                        ]),
                        startPoint: CGPoint(x: left, y: 0),
                        endPoint: CGPoint(x: right, y: 0)
                    ),
                    lineWidth: 11
                )
            }

            var gaps = Path()
            for divider in 1..<40 {
                let center = point(Double(divider) * 200)
                gaps.move(to: offset(center, by: -6.5))
                gaps.addLine(to: offset(center, by: 6.5))
            }
            context.stroke(gaps, with: .color(.black.opacity(0.6)), lineWidth: 1)

            for tick in 0...40 {
                let tickRPM = Double(tick) * 200
                let center = point(tickRPM)
                let major = tick.isMultiple(of: 5)
                let color = tickRPM >= redline ? DashColor.red : DashColor.ink
                var mark = Path()
                mark.move(to: offset(center, by: 10))
                mark.addLine(to: offset(center, by: major ? 16 : 13))
                context.stroke(mark, with: .color(color.opacity(major ? 0.93 : 0.45)), lineWidth: major ? 1.3 : 1)
                if major {
                    let label = Text(String(tick / 5))
                        .font(.system(size: 16, weight: .bold, design: .monospaced))
                        .foregroundColor(color)
                    context.draw(label, at: offset(center, by: 25))
                }
            }

            let lampStart = size.width * 0.47
            let lampCount = 6
            for index in 0..<lampCount {
                let x = lampStart + CGFloat(index) * 13
                let threshold = 5_600.0 + Double(index) * 360
                let color = index < 2 ? DashColor.amber : DashColor.red
                let level = value >= threshold ? 0.22 + 0.78 * intensity : 0.15
                let lamp = CGRect(x: x, y: 9, width: 9, height: 3)
                context.fill(Path(roundedRect: lamp, cornerRadius: 1), with: .color(color.opacity(level)))
            }
        }
    }
}

private struct GearSurround: View {
    let illumination: Double

    var body: some View {
        Canvas { context, size in
            let center = size.width / 2
            let width = size.width
            let floor = size.height - 4
            let shoulder = size.height * 0.42
            let shape = Path { path in
                path.move(to: CGPoint(x: 16, y: shoulder))
                path.addLine(to: CGPoint(x: center - 118, y: shoulder))
                path.addLine(to: CGPoint(x: center - 78, y: floor - 14))
                path.addLine(to: CGPoint(x: center - 56, y: floor))
                path.addLine(to: CGPoint(x: center + 56, y: floor))
                path.addLine(to: CGPoint(x: center + 78, y: floor - 14))
                path.addLine(to: CGPoint(x: center + 118, y: shoulder))
                path.addLine(to: CGPoint(x: width - 16, y: shoulder))
            }

            var illuminated = context
            illuminated.addFilter(.blur(radius: 7))
            illuminated.stroke(shape, with: .color(DashColor.red.opacity(illumination * 0.7)), lineWidth: 11)

            let colorStops: [Gradient.Stop] = [
                .init(color: DashColor.red.opacity(0.02), location: 0),
                .init(color: DashColor.red.opacity(illumination * 0.8), location: 0.25),
                .init(color: DashColor.amber.opacity(illumination), location: 0.5),
                .init(color: DashColor.red.opacity(illumination * 0.8), location: 0.75),
                .init(color: DashColor.red.opacity(0.02), location: 1)
            ]
            context.stroke(
                shape,
                with: .linearGradient(
                    Gradient(stops: colorStops),
                    startPoint: .zero,
                    endPoint: CGPoint(x: width, y: 0)
                ),
                style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round)
            )
        }
    }
}

private struct ForcesView: View {
    let longitudinal: Double?
    let lateral: Double?
    let peak: Double

    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private var plottedPoint: CGPoint {
        CGPoint(x: lateral ?? 0, y: longitudinal ?? 0)
    }

    private var magnitudeText: String {
        guard let longitudinal, let lateral else { return "—" }
        return formatted(hypot(longitudinal, lateral))
    }

    var body: some View {
        HStack(spacing: 8) {
            GPlot(point: plottedPoint, hasReading: longitudinal != nil && lateral != nil)
                .frame(width: 76, height: 76)
                .animation(reduceMotion ? nil : .linear(duration: 0.09), value: plottedPoint)
                .accessibilityHidden(true)

            VStack(alignment: .leading, spacing: 3) {
                Text("FORÇA G")
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .tracking(0.6)
                    .foregroundStyle(DashColor.muted)
                Text(magnitudeText)
                    .font(.system(size: 20, weight: .bold, design: .monospaced))
                    .monospacedDigit()
                    .foregroundStyle(DashColor.ink)
                Text("PICO \(formatted(peak))")
                    .font(.system(size: 9, weight: .semibold, design: .monospaced))
                    .monospacedDigit()
                    .foregroundStyle(DashColor.muted)
            }
            .lineLimit(1)
            .minimumScaleFactor(0.7)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Força G \(magnitudeText). Pico \(formatted(peak))")
    }

    private func formatted(_ value: Double) -> String {
        value.formatted(
            .number.precision(.fractionLength(2)).locale(Locale(identifier: "pt_BR"))
        )
    }
}

private struct GPlot: View, Animatable {
    var point: CGPoint
    let hasReading: Bool

    var animatableData: AnimatablePair<CGFloat, CGFloat> {
        get { AnimatablePair(point.x, point.y) }
        set { point = CGPoint(x: newValue.first, y: newValue.second) }
    }

    var body: some View {
        Canvas { context, size in
            let center = CGPoint(x: size.width / 2, y: size.height / 2)
            let radius = min(size.width, size.height) / 2 - 4
            let crossColor = DashColor.muted.opacity(0.45)

            func circle(center: CGPoint, radius: CGFloat) -> Path {
                Path(ellipseIn: CGRect(
                    x: center.x - radius, y: center.y - radius,
                    width: radius * 2, height: radius * 2
                ))
            }

            context.stroke(circle(center: center, radius: radius), with: .color(crossColor), lineWidth: 1)
            context.stroke(circle(center: center, radius: radius * 0.5), with: .color(crossColor), lineWidth: 0.7)

            var cross = Path()
            cross.move(to: CGPoint(x: center.x - radius, y: center.y))
            cross.addLine(to: CGPoint(x: center.x + radius, y: center.y))
            cross.move(to: CGPoint(x: center.x, y: center.y - radius))
            cross.addLine(to: CGPoint(x: center.x, y: center.y + radius))
            context.stroke(cross, with: .color(crossColor), style: StrokeStyle(lineWidth: 0.8, dash: [2, 3]))

            guard hasReading else { return }
            let range = max(1.25, hypot(point.x, point.y))
            let marker = CGPoint(
                x: center.x + point.x / range * radius,
                y: center.y - point.y / range * radius
            )
            var ray = Path()
            ray.move(to: center)
            ray.addLine(to: marker)
            context.stroke(ray, with: .color(DashColor.amber.opacity(0.65)), lineWidth: 1)
            context.fill(circle(center: marker, radius: 7), with: .color(DashColor.amber.opacity(0.24)))
            context.fill(circle(center: marker, radius: 3.7), with: .color(DashColor.amber))
        }
    }
}
