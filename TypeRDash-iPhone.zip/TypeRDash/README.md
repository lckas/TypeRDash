# TypeRDash para iPhone

Painel automotivo nativo em Swift e SwiftUI para **iPhone com iOS 16 ou posterior**, em orientação horizontal. O desenho vetorial é inspirado no modo +R do Civic Type R FL5. Conta-giros, iluminação e textura são desenhados pelo app. As imagens consultadas serviram como referência.

## Usar o painel

1. Abra o app com o iPhone em um suporte firme, na horizontal.
2. Autorize **Durante o Uso do App** com **Localização Precisa**. Aguarde **GPS ATIVO**. O número abaixo desse status indica a margem estimada de posição, em metros.
3. Confira o perfil em **Ajustes → Relações, pneus e pontos de troca**. O brilho é aplicado à interface e pode ser ajustado sem alterar o brilho global do iPhone.
4. Para o medidor G, monte a traseira do iPhone voltada para a frente do veículo e a tela para a cabine. Evite um suporte que deixe a tela quase paralela ao piso. Com o carro parado em superfície plana, mantenha o iPhone imóvel por um instante e toque em **Ajustes → Calibrar força G**. Repita depois de mover o suporte.
5. Toque no cronômetro do painel para iniciar ou pausar. **Ajustes** mostra as estatísticas e permite zerar o cronômetro e a viagem independentemente.
6. Ative **Modo DEMO** em **Ajustes** para testar parado. O ciclo inclui partida, aceleração, velocidade constante, frenagem e curvas. O painel exibe **DEMO** e isola as estatísticas de teste. Ao reabrir o app, o modo normal usa GPS.

No modo normal, a velocidade vem de `CLLocation.speed`, em km/h. O GPS tem prioridade e o app mantém a leitura em primeiro plano. O filtro exige posição com precisão horizontal de até 30 m e precisão de velocidade de até 1,5 m/s. Aplica histerese perto de zero e interpola brevemente entre leituras válidas. Leituras de baixa qualidade, posições identificadas pelo iOS como simuladas, indisponibilidade e permissões insuficientes deixam o velocímetro com **—**. Sem nova leitura a anterior expira em aproximadamente 2,5 s, mais até 250 ms do intervalo do verificador. A operação usa os sensores e funciona offline. A aquisição inicial pode demorar mais sem assistência de rede.

A distância é a integral da velocidade GPS válida. A média usa o tempo em movimento medido e intervalos sem sinal ficam fora do cálculo. As estatísticas duram a sessão do app. O cronômetro acumula tempo enquanto estiver iniciado, inclusive se o app for para segundo plano. O painel evita o bloqueio automático enquanto está ativo. Ao sair do painel ou ir para segundo plano, o iPhone volta a usar seu comportamento de bloqueio normal.

A força G é medida no iPhone com CoreMotion, compensação de gravidade e filtragem de vibração. O ponto sobe na aceleração, desce na frenagem e acompanha a aceleração lateral. O pico é a magnitude combinada medida na sessão. GPS, CoreMotion e o bloqueio de tela são gerenciados conforme o estado do app. Preferências e calibração ficam no aparelho.

**EST.** sinaliza RPM e marcha estimados. A simulação usa a velocidade, a aceleração e as relações de transmissão para estimar a rotação acoplada, o efeito da embreagem na primeira marcha, as trocas e a desaceleração. **N** é ponto morto estimado durante parada ou movimento muito lento. **SIM** sinaliza as temperaturas ilustrativas. As três temperaturas simuladas variam com carga, rotação, velocidade e tempo, com limites de 96 °C, 108 °C e 50 °C para motor, óleo e admissão. O app não oferece diagnóstico do motor. Faça ajustes com o veículo parado. Com falha no sensor original, o reparo continua necessário para recuperar a medição do próprio carro.

## Perfil de transmissão

| Parâmetro | Referência do Civic EX 1998 manual |
| --- | --- |
| Motor | D16Y8, 1.590 cm³, SOHC 16V VTEC |
| Marchas | 3,250 · 1,909 · 1,250 · 0,909 · 0,702 |
| Diferencial | 4,250 |
| Pneus | 185/65 R14 86T |
| Rotação limite inicial da simulação | 7.000 RPM |
| Pontos iniciais de troca simulada | Subida sob carga a 5.800 RPM, redução em ritmo constante a 1.750 RPM |

A Honda Brasil documenta essas relações, pneus e diferencial para o EX manual. O LX/LXB manual usa relações de 1,782 e 1,172 na 2ª e 3ª e diferencial de 4,058. O EX automático usa diferencial de 4,357. A Honda identifica o D16Y8 no EX brasileiro da geração. O manual de oficina norte-americano do Civic D16Y8 da mesma geração informa corte de combustível acima de 7.000 RPM. Esse é o valor inicial editável. A calibração de ECU, o código da caixa e as medidas instaladas no carro precisam ser conferidos fisicamente. A faixa gráfica de 7.000–8.000 RPM é própria do visual do painel.

O ponto de subida fica mais baixo em condução leve, e o de redução sobe sob frenagem. Um intervalo mínimo entre trocas e margens de rotação reduzem oscilações perto dos limiares. A geometria do pneu serve à estimativa de rotação. O desgaste ou a dimensão informada do pneu não alteram a velocidade obtida pelo GPS.

- [Manual do proprietário Honda Civic 1998, Honda Brasil, pp. 5-3 e 9-4 a 9-6](https://www.honda.com.br/pos-venda/automoveis/sites/customer_service/files/2018-01/1998%203BS01625%20miolo%20civic%2098.pdf)
- [Identificação dos motores, Honda Brasil](https://www.honda.com.br/automoveis/sites/hab/files/2025-04/Tabela_de_Ru%C3%ADdo_parado_Portaria_85_4W_2025_03_31.pdf)
- [Manual de oficina do Civic da mesma geração, seção PGM-FI](https://charm.li/Honda/2000/Civic%20EX%20Sedan%20L4-1590cc%201.6L%20SOHC%20%28VTEC%29%20MFI/Repair%20and%20Diagnosis/Powertrain%20Management/Description%20and%20Operation/Relays%2C%20Sensors%2C%20and%20Control%20Systems/)

## Compilar e instalar no iPhone com Xcode

1. Extraia o ZIP. Em um Mac, instale **Xcode 16 ou posterior**, em versão compatível com o iOS do seu iPhone.
2. Abra `TypeRDash.xcodeproj`. Selecione o esquema **TypeRDash**. O projeto inclui os fontes, catálogo de assets, ícone e configuração de permissões. XcodeGen e gerenciadores de dependências não são necessários.
3. Para rodar no simulador, selecione um modelo de iPhone e pressione **⌘R**. Use **Ajustes → Modo DEMO** para verificar a interface. GPS e movimento devem ser validados no aparelho.
4. Para instalar no próprio iPhone, entre no Xcode em **Settings → Accounts** com sua conta Apple. Selecione o target **TypeRDash → Signing & Capabilities**, deixe **Automatically manage signing** ativo e selecione sua **Personal Team** ou equipe de desenvolvimento. Se o identificador estiver indisponível, use um identificador único, por exemplo `com.seunome.typerdash`.
5. Conecte o iPhone, desbloqueie e aceite **Confiar neste computador**. Se solicitado, ative **Ajustes → Privacidade e Segurança → Modo de Desenvolvedor** e confirme após reiniciar. Selecione o iPhone no Xcode e pressione **⌘R**. Se o iOS solicitar confiança no perfil de desenvolvedor, siga a opção exibida em **Ajustes → Geral → VPN e Gerenciamento de Dispositivo**.
6. A assinatura gratuita da Personal Team expira em sete dias. Recompile e instale novamente no mesmo aparelho com o mesmo identificador para renovar. O projeto inclui código-fonte e configuração de assinatura automática, e a assinatura é aplicada usando a sua equipe.

Para executar os testes da aplicação no Mac, selecione um simulador e use **Product → Test** (⌘U). Pelo terminal, uma compilação de simulador pode ser feita assim.

```sh
xcodebuild -project TypeRDash.xcodeproj -scheme TypeRDash \
  -configuration Debug -destination 'generic/platform=iOS Simulator' \
  CODE_SIGNING_ALLOWED=NO build
```

- [Rodar em dispositivo ou simulador, Apple](https://developer.apple.com/documentation/xcode/running-your-app-on-simulated-or-physical-devices)
- [Ativar o modo de desenvolvedor, Apple](https://developer.apple.com/documentation/xcode/enabling-developer-mode-on-a-device)
- [Limites da Personal Team, Apple](https://developer.apple.com/help/account/basics/about-your-developer-account/)

## Se seu computador é Windows

O Windows pode abrir os arquivos-fonte e executar os testes do núcleo com um toolchain Swift compatível. A compilação completa requer macOS com Xcode e SDK iOS.

- **Com acesso temporário a um Mac**, siga as etapas do Xcode com a Personal Team. É a opção direta e gratuita para instalar e renovar no iPhone.
- **Com compilação em um Mac remoto ou runner macOS**, é possível gerar um pacote de aparelho sem assinatura e assinar com o AltStore Classic no Windows. Primeiro, no Mac, use o comando abaixo. Em seguida, transfira `TypeRDash.ipa` para o Windows e siga a instalação do AltServer/AltStore Classic. Importe o IPA pelo AltStore no iPhone. O AltStore é externo a este projeto e depende da disponibilidade do seu fluxo de assinatura, dos pré-requisitos descritos pelo fornecedor e das limitações da conta Apple gratuita. Renove a assinatura antes de expirar.

```sh
xcodebuild -project TypeRDash.xcodeproj -scheme TypeRDash \
  -configuration Release -destination 'generic/platform=iOS' \
  -derivedDataPath build-ios CODE_SIGNING_ALLOWED=NO build
mkdir -p build-ios/ipa/Payload
ditto build-ios/Build/Products/Release-iphoneos/TypeRDash.app \
  build-ios/ipa/Payload/TypeRDash.app
(cd build-ios/ipa && zip -qr ../TypeRDash.ipa Payload)
```

- [Instalação do AltStore Classic no Windows](https://faq.altstore.io/altstore-classic/how-to-install-altstore-classic/altstore-windows)
- [Como instalar um IPA pelo AltStore Classic](https://faq.altstore.io/altstore-classic/your-altstore)

## CarPlay

O CarPlay convencional concede entitlements por categoria após revisão da Apple. O guia lista categorias como áudio, comunicação, tarefas de condução, recarga elétrica, abastecimento, navegação, estacionamento e segurança pública. A categoria de tarefas de condução usa templates do sistema e limita atualizações periódicas a uma por dez segundos. Esse formato não comporta a velocidade contínua e os instrumentos desenhados deste painel. Widgets e Live Activities, onde disponíveis, são superfícies compactas. No CarPlay Ultra, instrumentos e temas são integrados pela Apple e a montadora em veículos compatíveis. O projeto é distribuído como app de iPhone, sem entitlement de CarPlay.

- [CarPlay Framework, Apple](https://developer.apple.com/documentation/carplay)
- [CarPlay Developer Guide, Apple, pp. 4–7](https://developer.apple.com/download/files/CarPlay-Developer-Guide.pdf)
- [Preparar um app para CarPlay e solicitar o entitlement, Apple](https://developer.apple.com/documentation/carplay/preparing-your-ios-app-for-carplay-development)
- [CarPlay Ultra, Apple](https://www.apple.com/newsroom/2025/05/carplay-ultra-the-next-generation-of-carplay-begins-rolling-out-today/)

## Validação e referências do painel

`swift test` na raiz executa os testes do núcleo de GPS, transmissão, temperaturas, viagem e demonstração. Os mesmos testes estão no esquema do Xcode. O núcleo foi executado em Linux com Swift 6.1.3. Os arquivos Swift passaram pela análise sintática, e foram verificados o projeto, o esquema, as permissões e o catálogo de assets. A compilação contra o SDK iOS, a aparência em tela, a calibração com o aparelho instalado e a taxa de quadros seguem pendentes de verificação em Xcode e iPhone.

- [Foto oficial do painel Type R, Honda News](https://hondanews.com/en-US/honda-automobiles/releases/release-40b876fa88ce36bf41449f6e4401464a/photos/17)
- [Driver Information Interface, Honda Info Center](https://www.hondainfocenter.com/2023/Civic-Type-R/Feature-Guide/Interior-Features/Driver-Information-Interface/)
- [Vídeo do interior do Civic Type R, Honda](https://www.youtube.com/watch?v=D1GlYu3xSug)
- Referências abertas consultadas para localização, interface e movimento. O projeto implementa o uso dos sensores diretamente. [SwiftLocation](https://github.com/malcommac/SwiftLocation) · [HorizonLens HUD](https://github.com/Wenshuishi0528/HorizonLensHUD-iPhone)
